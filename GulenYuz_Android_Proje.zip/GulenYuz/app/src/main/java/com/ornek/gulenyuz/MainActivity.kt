package com.ornek.gulenyuz

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var chooseButton: Button
    private val selected = mutableListOf<Uri>()
    private var processed = 0
    private var failed = 0

    private val picker = registerForActivityResultCompat()

    // Small wrapper keeps the project compatible with the platform document picker.
    private fun registerForActivityResultCompat(): (Int) -> Unit = { requestCode ->
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, requestCode)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            gravity = Gravity.TOP
        }
        val heading = TextView(this).apply {
            text = "😊  Gülen Yüz Fotoğraf Düzenleyici"
            textSize = 23f
            setTypeface(null, Typeface.BOLD)
        }
        val info = TextView(this).apply {
            text = "Fotoğraflardaki yüzleri otomatik bulur ve 😊 emojisiyle tamamen kapatır. İşlem telefonda yapılır; fotoğraflar internete gönderilmez."
            textSize = 16f
            setPadding(0, 22, 0, 22)
        }
        chooseButton = Button(this).apply {
            text = "Fotoğraf seç (en fazla 100)"
            setOnClickListener { picker(1001) }
        }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = ProgressBar.GONE
        }
        status = TextView(this).apply {
            text = "Hazır. Bir veya birden fazla fotoğraf seçebilirsin."
            textSize = 15f
            setPadding(0, 22, 0, 0)
        }
        root.addView(heading)
        root.addView(info)
        root.addView(chooseButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 12).apply { topMargin = 24 })
        root.addView(status)
        setContentView(root)
    }

    @Deprecated("Platform document picker callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 1001 || resultCode != RESULT_OK || data == null) return
        selected.clear()
        data.clipData?.let { clip ->
            for (i in 0 until minOf(clip.itemCount, 100)) selected.add(clip.getItemAt(i).uri)
        } ?: data.data?.let { selected.add(it) }
        if (selected.isEmpty()) return
        processed = 0; failed = 0
        progress.progress = 0
        progress.visibility = ProgressBar.VISIBLE
        chooseButton.isEnabled = false
        status.text = "${selected.size} fotoğraf seçildi. Yüzler taranıyor…"
        processNext(0)
    }

    private fun processNext(index: Int) {
        if (index >= selected.size) {
            progress.visibility = ProgressBar.GONE
            chooseButton.isEnabled = true
            status.text = "Tamamlandı: $processed fotoğraf kaydedildi. Hata: $failed. Sonuçlar Galeri > GülenYuz klasöründe."
            return
        }
        val uri = selected[index]
        try {
            val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            if (bitmap == null) { failed++; updateAndContinue(index); return }
            val options = FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE)
                .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE)
                .build()
            val detector = FaceDetection.getClient(options)
            detector.process(InputImage.fromBitmap(bitmap, 0))
                .addOnSuccessListener { faces ->
                    try {
                        val output = bitmap.copy(Bitmap.Config.ARGB_8888, true)
                        val canvas = Canvas(output)
                        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            textAlign = Paint.Align.CENTER
                            typeface = Typeface.DEFAULT
                        }
                        faces.forEach { face ->
                            val r = face.boundingBox
                            // Oversized emoji fully masks the detected face, including facial features.
                            val size = maxOf(r.width(), r.height()) * 1.42f
                            paint.textSize = size
                            val x = r.exactCenterX()
                            val y = r.exactCenterY() - (paint.ascent() + paint.descent()) / 2f
                            canvas.drawText("😊", x, y, paint)
                        }
                        if (saveBitmap(output)) processed++ else failed++
                    } catch (_: Exception) { failed++ }
                    detector.close()
                    updateAndContinue(index)
                }
                .addOnFailureListener {
                    failed++
                    detector.close()
                    updateAndContinue(index)
                }
        } catch (_: Exception) {
            failed++
            updateAndContinue(index)
        }
    }

    private fun updateAndContinue(index: Int) {
        runOnUiThread {
            progress.progress = (((index + 1).toFloat() / selected.size) * 100).toInt()
            status.text = "İşleniyor: ${index + 1}/${selected.size}  •  Kaydedilen: $processed"
            processNext(index + 1)
        }
    }

    private fun saveBitmap(bitmap: Bitmap): Boolean {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "GulenYuz_$stamp.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/GulenYuz")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        return try {
            contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 95, it) } ?: false
        } catch (_: Exception) {
            contentResolver.delete(uri, null, null)
            false
        }
    }
}
