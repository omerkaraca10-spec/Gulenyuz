plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ornek.gulenyuz"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.ornek.gulenyuz"
        minSdk = 29
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
    // Bundled model: face detection runs on-device after installation; no network is used.
    implementation("com.google.mlkit:face-detection:16.1.7")
}
